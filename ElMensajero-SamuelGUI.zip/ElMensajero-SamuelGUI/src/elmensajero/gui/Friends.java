
package elmensajero.gui;

import javafx.scene.layout.VBox;


/**
 *
 * @author Vinicius
 */
public class Friends extends VBox {

    Friends(){
        
    }

    
}
